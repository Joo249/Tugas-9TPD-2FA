<?php
require_once '../includes/db.php';
$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$secret = $_POST['secret'];
$stmt = $conn->prepare("INSERT INTO users (username, password, secret) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $password, $secret);
$stmt->execute();
header("Location: ../templates/login_form.php");
?>