<?php
session_start();
require_once '../vendor/autoload.php';
$otp = $_POST['otp'];
$secret = $_SESSION['secret'];
$ga = new PHPGangsta_GoogleAuthenticator();
$check = $ga->verifyCode($secret, $otp, 2);
if ($check) {
  header("Location: ../pages/dashboard.php");
} else {
  echo "OTP salah atau kadaluarsa.";
}
?>