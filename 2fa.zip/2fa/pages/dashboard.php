<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: ../templates/login_form.php"); exit; }
echo "Selamat datang, " . $_SESSION['username'] . " | <a href='../pages/logout.php'>Logout</a>";
?>