<?php
require_once '../vendor/autoload.php';
$ga = new PHPGangsta_GoogleAuthenticator();
$secret = $ga->createSecret();
$qrCodeUrl = $ga->getQRCodeGoogleUrl('MySecureApp', $secret);
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>Register</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script>
function validateForm() {
  const u = document.forms["regForm"]["username"].value;
  const p = document.forms["regForm"]["password"].value;
  if (u === "" || p === "") { alert("Wajib isi semua field"); return false; }
  return true;
}
</script></head>
<body class="bg-light"><div class="container mt-5"><div class="row justify-content-center">
<div class="col-md-5"><div class="card shadow-sm"><div class="card-header text-center"><h4>Registrasi</h4></div>
<div class="card-body"><form name="regForm" action="../controllers/register_process.php" method="POST" onsubmit="return validateForm();">
<div class="mb-3"><label>Username</label><input type="text" name="username" class="form-control"></div>
<div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control"></div>
<input type="hidden" name="secret" value="<?php echo $secret; ?>">
<div class="mb-3 text-center"><p>Scan QR Code:</p><img src="<?php echo $qrCodeUrl; ?>" alt="QR Code"></div>
<button type="submit" class="btn btn-primary w-100">Daftar</button></form></div></div></div></div></div></body></html>